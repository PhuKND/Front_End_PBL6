import React, { useState, useEffect, useRef } from 'react';
import { motion } from 'framer-motion';
import { useNavigate } from 'react-router-dom';

import {
  Box,
  Container,
  Typography,
  Button,
  Card,
  CardContent,
  CardMedia,
  Grid,
  Chip,
  Rating,
  IconButton,
  Paper,
  useTheme,
  useMediaQuery,
  Tabs,
  Tab,
  Link,
  Stack
} from '@mui/material';
import {
  ArrowForward as ArrowForwardIcon,
  Phone as PhoneIcon,
  LocalShipping as LocalShippingIcon,
  Security as SecurityIcon,
  CreditCard as CreditCardIcon,
  Headset as HeadsetIcon,
  Favorite as FavoriteIcon,
  ShoppingCart as ShoppingCartIcon,
  FlashOn as FlashIcon,
  AccessTime as TimeIcon,
  Whatshot as FireIcon,
  ChevronRight as ChevronRightIcon
} from '@mui/icons-material';

const HomePage = () => {
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('md'));
  const navigate = useNavigate();
  const flashSaleScrollRef = useRef(null);
  const bestSellerScrollRef = useRef(null);
  const [countdown, setCountdown] = useState({ hours: 10, minutes: 47, seconds: 41 });
  const [flashSaleTab, setFlashSaleTab] = useState(0);

  // Countdown timer
  useEffect(() => {
    const timer = setInterval(() => {
      setCountdown((prev) => {
        let { hours, minutes, seconds } = prev;
        if (seconds > 0) {
          seconds--;
        } else if (minutes > 0) {
          minutes--;
          seconds = 59;
        } else if (hours > 0) {
          hours--;
          minutes = 59;
          seconds = 59;
        }
        return { hours, minutes, seconds };
      });
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const flashSaleProducts = [
    {
      id: 201,
      name: 'Mặt nạ cấp ẩm Banobagi Stem Cell Vitamin Mask dưỡng da trắng sáng',
      price: '218.400',
      originalPrice: '280.000',
      discount: '22',
      unit: 'Hộp',
      image: 'https://images.unsplash.com/photo-1556228720-195a672e8a03?w=400&h=400&fit=crop'
    },
    {
      id: 202,
      name: 'VICHY V COLLAGEN SPECIALIST LIFTACTIV',
      price: '982.800',
      originalPrice: '1.260.000',
      discount: '22',
      unit: 'Hộp',
      image: 'https://images.unsplash.com/photo-1556228578-0d85b1a4d571?w=400&h=400&fit=crop'
    },
    {
      id: 203,
      name: 'VICHY V LIFTACTIV B3 SERUM',
      price: '998.400',
      originalPrice: '1.280.000',
      discount: '22',
      unit: 'Hộp',
      image: 'https://images.unsplash.com/photo-1556228720-195a672e8a03?w=400&h=400&fit=crop'
    },
    {
      id: 204,
      name: 'SVR CICAVIT+',
      price: '260.520',
      originalPrice: '334.000',
      discount: '22',
      unit: 'Hộp',
      image: 'https://images.unsplash.com/photo-1556228578-0d85b1a4d571?w=400&h=400&fit=crop'
    },
    {
      id: 205,
      name: 'SUPER AQUA MASK PACK',
      price: '171.600',
      originalPrice: '220.000',
      discount: '22',
      unit: 'Hộp',
      image: 'https://images.unsplash.com/photo-1556228720-195a672e8a03?w=400&h=400&fit=crop'
    },
    {
      id: 206,
      name: 'REAL RETINOL MASK PACK',
      price: '171.600',
      originalPrice: '220.000',
      discount: '22',
      unit: 'Hộp',
      image: 'https://images.unsplash.com/photo-1556228578-0d85b1a4d571?w=400&h=400&fit=crop'
    }
  ];

  const bestSellerProducts = [
    {
      id: 301,
      name: 'Thực phẩm bảo vệ sức khỏe NMN PQQ',
      price: '6.675.000',
      originalPrice: '8.900.000',
      discount: '25',
      unit: 'Hộp',
      packaging: 'Hộp 60 Viên',
      image: 'https://images.unsplash.com/photo-1587854692152-cbe660dbde88?w=400&h=400&fit=crop'
    },
    {
      id: 302,
      name: 'Viên uống Best King Jpanwell hỗ trợ tăng cường sinh lý và khả năng',
      price: '1.040.000',
      originalPrice: '1.300.000',
      discount: '20',
      unit: 'Hộp',
      packaging: 'Hộp 60 Viên',
      image: 'https://images.unsplash.com/photo-1556228578-0d85b1a4d571?w=400&h=400&fit=crop'
    },
    {
      id: 303,
      name: 'Viên uống giảm ho Nano Anpacov Biochempha (60 viên)',
      price: '119.200',
      originalPrice: '149.000',
      discount: '20',
      unit: 'Hộp',
      packaging: 'Hộp 60 Viên',
      image: 'https://images.unsplash.com/photo-1587854692152-cbe660dbde88?w=400&h=400&fit=crop'
    },
    {
      id: 304,
      name: 'Viên nhai Brauer Baby & Kids Ultra Pure DHA hỗ trợ phát triển não',
      price: '388.800',
      originalPrice: '486.000',
      discount: '20',
      unit: 'Hộp',
      packaging: 'Hộp 60 viên',
      image: 'https://images.unsplash.com/photo-1556228578-0d85b1a4d571?w=400&h=400&fit=crop'
    },
    {
      id: 305,
      name: 'Nước Yến Sào Cao Cấp Nunest Relax - Ngủ Ngon, Giảm Căng thẳng',
      price: '246.750',
      originalPrice: '329.000',
      discount: '25',
      unit: 'Hộp',
      packaging: 'Hộp 6 Hũ x 70ml',
      image: 'https://images.unsplash.com/photo-1587854692152-cbe660dbde88?w=400&h=400&fit=crop'
    },
    {
      id: 306,
      name: 'Chai xịt Aloclair Plus Spray giảm đau nhanh bệnh tay chân miệng',
      price: '229.000',
      originalPrice: null,
      discount: null,
      unit: 'Hộp',
      packaging: 'Hộp x 15ml',
      image: 'https://images.unsplash.com/photo-1556228578-0d85b1a4d571?w=400&h=400&fit=crop'
    }
  ];

  const featuredProducts = [
    {
      id: 101,
      name: 'Thuốc',
      price: '80.000',
      originalPrice: '100.000',
      discount: '20%',
      image: 'https://images.unsplash.com/photo-1587854692152-cbe660dbde88?w=600&h=500&fit=crophttps://images.unsplash.com/photo-1587854692152-cbe660dbde88?w=600&h=500&fit=crop',
      rating: 5.0,
      reviews: 200
    },
    {
      id: 102,
      name: 'Thuốc',
      price: '80.000',
      originalPrice: '100.000',
      discount: '20%',
      image: 'https://images.unsplash.com/photo-1587854692152-cbe660dbde88?w=600&h=500&fit=crophttps://images.unsplash.com/photo-1587854692152-cbe660dbde88?w=600&h=500&fit=crop',
      rating: 5.0,
      reviews: 200
    },
    {
      id: 103,
      name: 'Thuốc',
      price: '80.000',
      originalPrice: '100.000',
      discount: '20%',
      image: 'https://images.unsplash.com/photo-1587854692152-cbe660dbde88?w=600&h=500&fit=crophttps://images.unsplash.com/photo-1587854692152-cbe660dbde88?w=600&h=500&fit=crop',
      rating: 5.0,
      reviews: 200


    },
    {
      id: 104,
      name: 'Thuốc',
      price: '80.000',
      originalPrice: '100.000',
      discount: '20%',
      image: 'https://images.unsplash.com/photo-1587854692152-cbe660dbde88?w=600&h=500&fit=crophttps://images.unsplash.com/photo-1587854692152-cbe660dbde88?w=600&h=500&fit=crop',
      rating: 5.0,
      reviews: 200
    }
  ];

  const categories = [
    { name: 'Thần kinh não', icon: '🧠', count: '100+' },
    { name: 'Vitamin & Khoáng chất', icon: '🧪', count: '100+' },
    { name: 'Sức khoẻ tim mạch', icon: '❤️‍🩹', count: '100+' },
    { name: 'Tiêm Vắc Xin', icon: '🛡️', count: '100+' },
    // { name: 'Hỗ trợ tiêu hoá', icon: '🥗', count: '100+' },
    { name: 'Sinh lý – Nội tiết tố', icon: '🧬', count: '100+' },
    { name: 'Dinh dưỡng', icon: '🥗', count: '100+' },
    // { name: 'Thuốc bổ', icon: '💊', count: '100+' },
    // { name: 'Chăm sóc da mặt', icon: '🧖', count: '100+' },
    { name: 'Hỗ trợ làm đẹp', icon: '💅', count: '100+' },
    { name: 'Hỗ trợ tình dục', icon: '❤️', count: '100+' },
    { name: 'Tư vấn với Bác Sĩ', icon: '👨‍⚕️', count: '100+' }
  ];

  const services = [
    {
      icon: <LocalShippingIcon sx={{ fontSize: 40 }} />,
      title: 'Giao hàng miễn phí',
      description: 'Giao hàng miễn phí cho đơn hàng từ 500k'
    },
    {
      icon: <SecurityIcon sx={{ fontSize: 40 }} />,
      title: 'Chất lượng đảm bảo',
      description: '100% sản phẩm chính hãng, có giấy phép'
    },
    {
      icon: <CreditCardIcon sx={{ fontSize: 40 }} />,
      title: 'Thanh toán an toàn',
      description: 'Hỗ trợ nhiều phương thức thanh toán'
    },
    {
      icon: <HeadsetIcon sx={{ fontSize: 40 }} />,
      title: 'Hỗ trợ 24/7',
      description: 'Tư vấn chuyên môn miễn phí'
    }
  ];

  return (
    <Box sx={{ minHeight: '100vh' }}>
      <Box
        sx={{
          position: 'relative',
          background: `linear-gradient(135deg, ${theme.palette.primary.main} 0%, ${theme.palette.primary.dark} 100%)`,
          color: 'white',
          overflow: 'hidden',
          '&::before': {
            content: '""',
            position: 'absolute',
            top: 0,
            left: 0,
            right: 0,
            bottom: 0,
            backgroundColor: 'rgba(0,0,0,0.2)',
            zIndex: 1
          }
        }}
      >
        <Container maxWidth="lg" sx={{ position: 'relative', zIndex: 2, py: 10 }}>
          <Grid container spacing={6} alignItems="center">
            <Grid item xs={12} lg={6}>
              <motion.div
                initial={{ opacity: 0, x: -50 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.8 }}
              >
                <Typography
                  variant={isMobile ? 'h3' : 'h2'}
                  component="h1"
                  sx={{ fontWeight: 'bold', mb: 3, lineHeight: 1.2 }}
                >
                  Sức khỏe của bạn
                  <Box component="span" sx={{ display: 'block', color: 'warning.main' }}>
                    Là ưu tiên hàng đầu
                  </Box>
                </Typography>
                <Typography variant="h6" sx={{ mb: 4, color: 'grey.100', lineHeight: 1.6 }}>
                  MedStore - Nơi cung cấp các sản phẩm chăm sóc sức khỏe chất lượng cao, 
                  với đội ngũ bác sĩ chuyên môn tư vấn 24/7.
                </Typography>
                <Box sx={{ display: 'flex', flexDirection: { xs: 'column', sm: 'row' }, gap: 2 }}>
                  <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                    <Button
                      variant="contained"
                      size="large"
                      endIcon={<ArrowForwardIcon />}
                      sx={{
                        bgcolor: 'warning.main',
                        color: 'white',
                        px: 4,
                        py: 1.5,
                        fontSize: '1.1rem',
                        fontWeight: 'bold',
                        '&:hover': { bgcolor: 'warning.dark' }
                      }}
                    >
                      Mua sắm ngay
                    </Button>
                  </motion.div>
                  <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                    <Button
                      variant="outlined"
                      size="large"
                      startIcon={<PhoneIcon />}
                      sx={{
                        borderColor: 'white',
                        color: 'white',
                        px: 4,
                        py: 1.5,
                        fontSize: '1.1rem',
                        fontWeight: 'bold',
                        '&:hover': {
                          borderColor: 'white',
                          bgcolor: 'white',
                          color: 'primary.main'
                        }
                      }}
                    >
                      Tư vấn miễn phí
                    </Button>
                  </motion.div>
                </Box>
              </motion.div>
            </Grid>
            <Grid item xs={12} lg={6}>
              <motion.div
                initial={{ opacity: 0, x: 50 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.8, delay: 0.2 }}
                style={{ position: 'relative' }}
              >
                <Box sx={{ position: 'relative', zIndex: 10 }}>
                  <Card
                    sx={{
                      borderRadius: 4,
                      overflow: 'hidden',
                      boxShadow: theme.shadows[20]
                    }}
                  >
                    <CardMedia
                      component="img"
                      image="https://images.unsplash.com/photo-1587854692152-cbe660dbde88?w=600&h=500&fit=crophttps://images.unsplash.com/photo-1587854692152-cbe660dbde88?w=600&h=500&fit=crop"
                      alt="Healthcare products"
                      sx={{ height: 400 }}
                    />
                  </Card>
                </Box>
                <Paper
                  sx={{
                    position: 'absolute',
                    bottom: -16,
                    right: -16,
                    p: 3,
                    borderRadius: 4,
                    boxShadow: theme.shadows[10],
                    textAlign: 'center'
                  }}
                >
                  <Typography variant="h3" sx={{ fontWeight: 'bold', color: 'primary.main' }}>
                    50K+
                  </Typography>
                  <Typography variant="body2" color="text.secondary">
                    Khách hàng tin tưởng
                  </Typography>
                </Paper>
              </motion.div>
            </Grid>
          </Grid>
        </Container>
      </Box>

      {/* FLASHSALE GIÁ TỐT Section */}
      <Box sx={{ py: 6, bgcolor: '#E3F2FD', position: 'relative' }}>
        <Container maxWidth="lg">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            {/* Header */}
            <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', mb: 3 }}>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
                <Box sx={{ position: 'relative' }}>
                  <Box
                    sx={{
                      width: 80,
                      height: 80,
                      borderRadius: '50%',
                      bgcolor: 'white',
                      display: 'flex',
                      alignItems: 'center',
                      justifyContent: 'center',
                      fontSize: '2.5rem',
                      boxShadow: theme.shadows[4]
                    }}
                  >
                    💊
                  </Box>
                  <motion.div
                    animate={{
                      y: [0, -10, 0],
                      rotate: [0, 10, -10, 0]
                    }}
                    transition={{
                      duration: 2,
                      repeat: Infinity,
                      ease: 'easeInOut'
                    }}
                    style={{
                      position: 'absolute',
                      top: -10,
                      right: -10,
                      fontSize: '1.5rem'
                    }}
                  >
                    🪙
                  </motion.div>
                </Box>
                <Box>
                  <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 0.5 }}>
                    <Typography
                      variant="h4"
                      sx={{
                        fontWeight: 'bold',
                        color: '#FFA726',
                        fontSize: { xs: '1.5rem', md: '2rem' }
                      }}
                    >
                      FLASHSALE
                    </Typography>
                    <FlashIcon sx={{ fontSize: 32, color: '#FFA726' }} />
                    <Typography
                      variant="h4"
                      sx={{
                        fontWeight: 'bold',
                        color: '#1976D2',
                        fontSize: { xs: '1.5rem', md: '2rem' }
                      }}
                    >
                      GIÁ TỐT
                    </Typography>
                  </Box>
                </Box>
              </Box>
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 2 }}>
                <Link
                  href="#"
                  sx={{
                    color: 'text.secondary',
                    textDecoration: 'none',
                    fontSize: '0.875rem',
                    '&:hover': { color: 'primary.main' }
                  }}
                >
                  Xem thể lệ &gt;
                </Link>
                <IconButton
                  sx={{
                    bgcolor: '#FF9800',
                    color: 'white',
                    '&:hover': { bgcolor: '#F57C00' }
                  }}
                >
                  <ChevronRightIcon />
                </IconButton>
              </Box>
            </Box>

            {/* Schedule Tabs */}
            <Paper sx={{ p: 2, mb: 3, bgcolor: 'white' }}>
              <Tabs
                value={flashSaleTab}
                onChange={(e, newValue) => setFlashSaleTab(newValue)}
                sx={{
                  '& .MuiTab-root': {
                    minWidth: { xs: 100, md: 150 },
                    fontSize: '0.875rem',
                    fontWeight: 500
                  },
                  '& .Mui-selected': {
                    color: '#D32F2F',
                    fontWeight: 'bold'
                  }
                }}
              >
                <Tab
                  label={
                    <Box>
                      <Typography variant="body2" sx={{ fontWeight: flashSaleTab === 0 ? 'bold' : 'normal' }}>
                        08:00 - 22:00, 22/11
                      </Typography>
                      <Typography variant="caption" sx={{ color: flashSaleTab === 0 ? '#D32F2F' : 'text.secondary' }}>
                        Đang diễn ra
                      </Typography>
                    </Box>
                  }
                />
                <Tab
                  label={
                    <Box>
                      <Typography variant="body2" sx={{ fontWeight: flashSaleTab === 1 ? 'bold' : 'normal' }}>
                        08:00 - 22:00, 23/11
                      </Typography>
                      <Typography variant="caption" sx={{ color: flashSaleTab === 1 ? '#D32F2F' : 'text.secondary' }}>
                        Sắp diễn ra
                      </Typography>
                    </Box>
                  }
                />
                <Tab
                  label={
                    <Box>
                      <Typography variant="body2" sx={{ fontWeight: flashSaleTab === 2 ? 'bold' : 'normal' }}>
                        08:00 - 22:00, 24/11
                      </Typography>
                      <Typography variant="caption" sx={{ color: flashSaleTab === 2 ? '#D32F2F' : 'text.secondary' }}>
                        Sắp diễn ra
                      </Typography>
                    </Box>
                  }
                />
              </Tabs>
            </Paper>

            {/* Countdown Timer */}
            <Paper
              sx={{
                p: 2,
                mb: 4,
                bgcolor: 'white',
                display: 'flex',
                alignItems: 'center',
                gap: 2,
                flexWrap: 'wrap'
              }}
            >
              <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                <TimeIcon sx={{ color: '#D32F2F' }} />
                <Typography variant="body2" fontWeight="bold">
                  Kết thúc sau:
                </Typography>
              </Box>
              <Box sx={{ display: 'flex', gap: 1 }}>
                <Chip
                  label={String(countdown.hours).padStart(2, '0')}
                  sx={{
                    bgcolor: '#D32F2F',
                    color: 'white',
                    fontWeight: 'bold',
                    fontSize: '1rem',
                    minWidth: 50,
                    height: 36
                  }}
                />
                <Typography sx={{ alignSelf: 'center', fontWeight: 'bold', color: '#D32F2F' }}>:</Typography>
                <Chip
                  label={String(countdown.minutes).padStart(2, '0')}
                  sx={{
                    bgcolor: '#D32F2F',
                    color: 'white',
                    fontWeight: 'bold',
                    fontSize: '1rem',
                    minWidth: 50,
                    height: 36
                  }}
                />
                <Typography sx={{ alignSelf: 'center', fontWeight: 'bold', color: '#D32F2F' }}>:</Typography>
                <Chip
                  label={String(countdown.seconds).padStart(2, '0')}
                  sx={{
                    bgcolor: '#D32F2F',
                    color: 'white',
                    fontWeight: 'bold',
                    fontSize: '1rem',
                    minWidth: 50,
                    height: 36
                  }}
                />
              </Box>
            </Paper>

            {/* Flash Sale Products Carousel */}
            <Box
              ref={flashSaleScrollRef}
              sx={{
                display: 'flex',
                gap: 2,
                overflowX: 'auto',
                pb: 2,
                scrollBehavior: 'smooth',
                '&::-webkit-scrollbar': { height: 8 },
                '&::-webkit-scrollbar-thumb': {
                  bgcolor: 'grey.400',
                  borderRadius: 4
                }
              }}
            >
              {flashSaleProducts.map((product, index) => (
                <motion.div
                  key={product.id}
                  initial={{ opacity: 0, x: 20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.4, delay: index * 0.1 }}
                  style={{ minWidth: 280 }}
                >
                  <Card
                    onClick={() => navigate(`/product/${product.id}`)}
                    sx={{
                      height: '100%',
                      cursor: 'pointer',
                      transition: 'all 0.3s',
                      bgcolor: 'white',
                      '&:hover': {
                        transform: 'translateY(-4px)',
                        boxShadow: theme.shadows[8]
                      }
                    }}
                  >
                    <Box sx={{ position: 'relative' }}>
                      <CardMedia
                        component="img"
                        image={product.image}
                        alt={product.name}
                        sx={{ height: 200, objectFit: 'cover' }}
                      />
                      <Chip
                        label={`-${product.discount}%`}
                        sx={{
                          position: 'absolute',
                          top: 8,
                          left: 8,
                          bgcolor: '#D32F2F',
                          color: 'white',
                          fontWeight: 'bold',
                          fontSize: '0.875rem',
                          height: 28
                        }}
                      />
                    </Box>
                    <CardContent sx={{ p: 2 }}>
                      <Typography
                        variant="body2"
                        sx={{
                          mb: 1.5,
                          height: 40,
                          overflow: 'hidden',
                          textOverflow: 'ellipsis',
                          display: '-webkit-box',
                          WebkitLineClamp: 2,
                          WebkitBoxOrient: 'vertical',
                          lineHeight: 1.4
                        }}
                      >
                        {product.name}
                      </Typography>
                      <Typography
                        variant="h6"
                        sx={{
                          fontWeight: 'bold',
                          color: '#1976D2',
                          mb: 0.5,
                          fontSize: '1.1rem'
                        }}
                      >
                        {product.price}₫ / {product.unit}
                      </Typography>
                      <Typography
                        variant="body2"
                        sx={{
                          color: 'text.secondary',
                          textDecoration: 'line-through',
                          mb: 1.5
                        }}
                      >
                        {product.originalPrice}₫
                      </Typography>
                      <Box
                        sx={{
                          display: 'flex',
                          alignItems: 'center',
                          gap: 0.5,
                          bgcolor: '#FFE0B2',
                          px: 1,
                          py: 0.5,
                          borderRadius: 1,
                          mb: 1.5,
                          width: 'fit-content'
                        }}
                      >
                        <FireIcon sx={{ fontSize: 16, color: '#FF9800' }} />
                        <Typography variant="caption" sx={{ color: '#E65100', fontWeight: 'bold' }}>
                          Ưu đãi giá sốc
                        </Typography>
                      </Box>
                      <Button
                        fullWidth
                        variant="contained"
                        sx={{
                          bgcolor: '#1976D2',
                          color: 'white',
                          fontWeight: 'bold',
                          '&:hover': { bgcolor: '#1565C0' }
                        }}
                      >
                        Chọn mua
                      </Button>
                    </CardContent>
                  </Card>
                </motion.div>
              ))}
            </Box>

            {/* View All Link */}
            <Box sx={{ textAlign: 'center', mt: 3 }}>
              <Link
                href="#"
                sx={{
                  color: '#1976D2',
                  textDecoration: 'none',
                  fontWeight: 'bold',
                  fontSize: '1rem',
                  '&:hover': { textDecoration: 'underline' }
                }}
              >
                Xem tất cả &gt;
              </Link>
            </Box>
          </motion.div>
        </Container>
      </Box>

      {/* Sản phẩm bán chạy Section */}
      <Box sx={{ py: 6, bgcolor: '#E3F2FD', position: 'relative' }}>
        <Container maxWidth="lg">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
          >
            {/* Header Banner */}
            <Box sx={{ textAlign: 'center', mb: 4 }}>
              <Paper
                sx={{
                  display: 'inline-block',
                  px: 4,
                  py: 1.5,
                  borderRadius: 4,
                  bgcolor: '#D32F2F',
                  color: 'white'
                }}
              >
                <Typography variant="h5" sx={{ fontWeight: 'bold' }}>
                  Sản phẩm bán chạy
                </Typography>
              </Paper>
            </Box>

            {/* Best Seller Products Carousel */}
            <Box sx={{ position: 'relative' }}>
              <Box
                ref={bestSellerScrollRef}
                sx={{
                  display: 'flex',
                  gap: 2,
                  overflowX: 'auto',
                  pb: 2,
                  scrollBehavior: 'smooth',
                  '&::-webkit-scrollbar': { height: 8 },
                  '&::-webkit-scrollbar-thumb': {
                    bgcolor: 'grey.400',
                    borderRadius: 4
                  }
                }}
              >
                {bestSellerProducts.map((product, index) => (
                  <motion.div
                    key={product.id}
                    initial={{ opacity: 0, x: 20 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    transition={{ duration: 0.4, delay: index * 0.1 }}
                    style={{ minWidth: 280 }}
                  >
                    <Card
                      onClick={() => navigate(`/product/${product.id}`)}
                      sx={{
                        height: '100%',
                        cursor: 'pointer',
                        transition: 'all 0.3s',
                        bgcolor: 'white',
                        '&:hover': {
                          transform: 'translateY(-4px)',
                          boxShadow: theme.shadows[8]
                        }
                      }}
                    >
                      <Box sx={{ position: 'relative' }}>
                        <CardMedia
                          component="img"
                          image={product.image}
                          alt={product.name}
                          sx={{ height: 200, objectFit: 'cover' }}
                        />
                        {product.discount && (
                          <Chip
                            label={`-${product.discount}%`}
                            sx={{
                              position: 'absolute',
                              top: 8,
                              left: 8,
                              bgcolor: '#D32F2F',
                              color: 'white',
                              fontWeight: 'bold',
                              fontSize: '0.875rem',
                              height: 28
                            }}
                          />
                        )}
                      </Box>
                      <CardContent sx={{ p: 2 }}>
                        <Typography
                          variant="body2"
                          sx={{
                            mb: 1.5,
                            height: 50,
                            overflow: 'hidden',
                            textOverflow: 'ellipsis',
                            display: '-webkit-box',
                            WebkitLineClamp: 3,
                            WebkitBoxOrient: 'vertical',
                            lineHeight: 1.4
                          }}
                        >
                          {product.name}
                        </Typography>
                        <Typography
                          variant="h6"
                          sx={{
                            fontWeight: 'bold',
                            color: '#1976D2',
                            mb: 0.5,
                            fontSize: '1.1rem'
                          }}
                        >
                          {product.price}₫ / {product.unit}
                        </Typography>
                        {product.originalPrice && (
                          <Typography
                            variant="body2"
                            sx={{
                              color: 'text.secondary',
                              textDecoration: 'line-through',
                              mb: 1
                            }}
                          >
                            {product.originalPrice}₫
                          </Typography>
                        )}
                        <Typography variant="caption" sx={{ color: 'text.secondary', mb: 1.5, display: 'block' }}>
                          {product.packaging}
                        </Typography>
                        <Button
                          fullWidth
                          variant="contained"
                          sx={{
                            bgcolor: '#1976D2',
                            color: 'white',
                            fontWeight: 'bold',
                            '&:hover': { bgcolor: '#1565C0' }
                          }}
                        >
                          Chọn mua
                        </Button>
                      </CardContent>
                    </Card>
                  </motion.div>
                ))}
              </Box>
              <IconButton
                sx={{
                  position: 'absolute',
                  right: -20,
                  top: '50%',
                  transform: 'translateY(-50%)',
                  bgcolor: '#E3F2FD',
                  color: '#1976D2',
                  '&:hover': { bgcolor: '#BBDEFB' },
                  display: { xs: 'none', md: 'flex' }
                }}
                onClick={() => {
                  if (bestSellerScrollRef.current) {
                    bestSellerScrollRef.current.scrollBy({ left: 300, behavior: 'smooth' });
                  }
                }}
              >
                <ChevronRightIcon />
              </IconButton>
            </Box>
          </motion.div>
        </Container>
      </Box>

      <Box sx={{ py: 10, bgcolor: 'grey.50' }}>
        <Container maxWidth="lg">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            style={{ textAlign: 'center', marginBottom: theme.spacing(8) }}
          >
            <Typography variant="h3" component="h2" sx={{ fontWeight: 'bold', mb: 2, color: 'text.primary' }}>
              Danh mục sản phẩm
            </Typography>
            <Typography variant="h6" sx={{ color: 'text.secondary', maxWidth: 600, mx: 'auto' }}>
              Khám phá đa dạng sản phẩm chăm sóc sức khỏe chất lượng cao
            </Typography>
          </motion.div>

          <Grid container spacing={4}>
            {categories.map((category, index) => (
              <Grid item xs={12} md={6} lg={4} key={index}>
                <motion.div
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: index * 0.1 }}
                  whileHover={{ y: -10 }}
                >
                  <Card
                    sx={{
                      height: '100%',
                      cursor: 'pointer',
                      transition: 'all 0.3s ease',
                      '&:hover': {
                        boxShadow: theme.shadows[10],
                        transform: 'translateY(-10px)'
                      }
                    }}
                    onClick={() => {
                      if (category.name.toLowerCase() === 'tư vấn với bác sĩ') {
                        navigate('/consult');
                      } else {
                        const slug = category.name
                          .trim()
                          .replace(/\s+/g, '-');
                        navigate(`/category/${encodeURIComponent(slug)}`);
                      }
                    }}
                  >
                    <CardContent sx={{ p: 4, textAlign: 'center' }}>
                      <Typography variant="h1" sx={{ mb: 2, fontSize: '4rem' }}>
                        {category.icon}
                      </Typography>
                      <Typography variant="h6" sx={{ fontWeight: 'semibold', mb: 1 }}>
                        {category.name}
                      </Typography>
                      <Typography variant="body2" color="text.secondary" sx={{ mb: 3 }}>
                        {category.count} sản phẩm
                      </Typography>
                      <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'primary.main' }}>
                        <Typography variant="body2" sx={{ fontWeight: 'medium' }}>
                          Xem tất cả
                        </Typography>
                        <ArrowForwardIcon sx={{ ml: 1, fontSize: '1rem' }} />
                      </Box>
                    </CardContent>
                  </Card>
                </motion.div>
              </Grid>
            ))}
          </Grid>
        </Container>
      </Box>

      <Box sx={{ py: 10 }}>
        <Container maxWidth="lg">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            style={{ textAlign: 'center', marginBottom: theme.spacing(8) }}
          >
            <Typography variant="h3" component="h2" sx={{ fontWeight: 'bold', mb: 2, color: 'text.primary' }}>
              Sản phẩm nổi bật
            </Typography>
            <Typography variant="h6" sx={{ color: 'text.secondary', maxWidth: 600, mx: 'auto' }}>
              Những sản phẩm được khách hàng tin tưởng và đánh giá cao
            </Typography>
          </motion.div>

          <Grid container spacing={4}>
            {featuredProducts.map((product, index) => (
              <Grid item xs={12} sm={6} md={3} key={product.id}>
                <motion.div
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: index * 0.1 }}
                  whileHover={{ y: -10 }}
                >
                      <Card
                    sx={{
                      height: '100%',
                      overflow: 'hidden',
                      transition: 'all 0.3s ease',
                      '&:hover': {
                        boxShadow: theme.shadows[10],
                        transform: 'translateY(-10px)'
                      }
                        }}
                        onClick={() => navigate(`/product/${product.id}`)}
                  >
                    <Box sx={{ position: 'relative' }}>
                      <CardMedia
                        component="img"
                        image={product.image}
                        alt={product.name}
                        sx={{ height: 200, objectFit: 'cover' }}
                      />
                      <Chip
                        label={`-${product.discount}`}
                        color="error"
                        size="small"
                        sx={{
                          position: 'absolute',
                          top: 16,
                          left: 16,
                          fontWeight: 'bold'
                        }}
                      />
                      <IconButton
                        sx={{
                          position: 'absolute',
                          top: 16,
                          right: 16,
                          bgcolor: 'white',
                          '&:hover': { bgcolor: 'grey.100' }
                        }}
                      >
                        <FavoriteIcon sx={{ color: 'grey.400' }} />
                      </IconButton>
                    </Box>
                    
                    <CardContent sx={{ p: 3 }}>
                      <Typography variant="h6" sx={{ fontWeight: 'semibold', mb: 2, lineHeight: 1.3 }}>
                        {product.name}
                      </Typography>
                      
                      <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
                        <Rating value={product.rating} precision={0.1} readOnly size="small" />
                        <Typography variant="body2" color="text.secondary" sx={{ ml: 1 }}>
                          ({product.reviews})
                        </Typography>
                      </Box>
                      
                      <Box sx={{ display: 'flex', alignItems: 'center', gap: 1, mb: 3 }}>
                        <Typography variant="h5" sx={{ fontWeight: 'bold', color: 'primary.main' }}>
                          {product.price}đ
                        </Typography>
                        <Typography variant="body2" color="text.secondary" sx={{ textDecoration: 'line-through' }}>
                          {product.originalPrice}đ
                        </Typography>
                      </Box>
                      
                      <Button
                        variant="contained"
                        fullWidth
                        startIcon={<ShoppingCartIcon />}
                        sx={{
                          bgcolor: 'primary.main',
                          '&:hover': { bgcolor: 'primary.dark' }
                        }}
                      >
                        Thêm vào giỏ
                      </Button>
                    </CardContent>
                  </Card>
                </motion.div>
              </Grid>
            ))}
          </Grid>
        </Container>
      </Box>

      <Box sx={{ py: 10, bgcolor: 'grey.50' }}>
        <Container maxWidth="lg">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            style={{ textAlign: 'center', marginBottom: theme.spacing(8) }}
          >
            <Typography variant="h3" component="h2" sx={{ fontWeight: 'bold', mb: 2, color: 'text.primary' }}>
              Tại sao chọn MedStore?
            </Typography>
            <Typography variant="h6" sx={{ color: 'text.secondary', maxWidth: 600, mx: 'auto' }}>
              Chúng tôi cam kết mang đến trải nghiệm mua sắm tốt nhất cho khách hàng
            </Typography>
          </motion.div>

          <Grid container spacing={4}>
            {services.map((service, index) => (
              <Grid item xs={12} sm={6} lg={3} key={index}>
                <motion.div
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.6, delay: index * 0.1 }}
                >
                  <Box sx={{ textAlign: 'center' }}>
                    <Box
                      sx={{
                        width: 80,
                        height: 80,
                        borderRadius: '50%',
                        bgcolor: 'white',
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        mx: 'auto',
                        mb: 3,
                        color: 'primary.main',
                        boxShadow: theme.shadows[4],
                        transition: 'transform 0.3s ease',
                        '&:hover': { transform: 'scale(1.1)' }
                      }}
                    >
                      {service.icon}
                    </Box>
                    <Typography variant="h6" sx={{ fontWeight: 'semibold', mb: 2 }}>
                      {service.title}
                    </Typography>
                    <Typography variant="body2" color="text.secondary">
                      {service.description}
                    </Typography>
                  </Box>
                </motion.div>
              </Grid>
            ))}
          </Grid>
        </Container>
      </Box>

      <Box sx={{ py: 10, bgcolor: 'primary.main', color: 'white' }}>
        <Container maxWidth="lg">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6 }}
            style={{ textAlign: 'center' }}
          >
            <Typography variant="h3" component="h2" sx={{ fontWeight: 'bold', mb: 3 }}>
              Sẵn sàng chăm sóc sức khỏe?
            </Typography>
            <Typography variant="h6" sx={{ mb: 4, color: 'grey.100', maxWidth: 600, mx: 'auto' }}>
              Tham gia cùng hàng nghìn khách hàng đã tin tưởng MedStore 
              để chăm sóc sức khỏe gia đình
            </Typography>
            <Box sx={{ display: 'flex', flexDirection: { xs: 'column', sm: 'row' }, gap: 2, justifyContent: 'center' }}>
              <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                <Button
                  variant="contained"
                  size="large"
                  sx={{
                    bgcolor: 'warning.main',
                    color: 'white',
                    px: 4,
                    py: 1.5,
                    fontSize: '1.1rem',
                    fontWeight: 'bold',
                    '&:hover': { bgcolor: 'warning.dark' }
                  }}
                >
                  Bắt đầu mua sắm
                </Button>
              </motion.div>
              <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
                <Button
                  variant="outlined"
                  size="large"
                  sx={{
                    borderColor: 'white',
                    color: 'white',
                    px: 4,
                    py: 1.5,
                    fontSize: '1.1rem',
                    fontWeight: 'bold',
                    '&:hover': {
                      borderColor: 'white',
                      bgcolor: 'white',
                      color: 'primary.main'
                    }
                  }}
                >
                  Liên hệ tư vấn
                </Button>
              </motion.div>
            </Box>
          </motion.div>
        </Container>
      </Box>
    </Box>
  );
};

export default HomePage;


